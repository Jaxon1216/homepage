# 原生 JavaScript CSR / SSR 小实验

同一份商品数据、同一套商品模板，分别在服务器和浏览器生成正文。只用 Node.js 内置模块、原生 JavaScript、HTML 和 CSS，无依赖、无构建。商品与插画均为本地虚构内容。

## 启动

需要 Node.js 20 或以上版本。在 `simple-ssr` 目录运行：

```sh
npm start
```

也可以直接运行 `node server/index.js`。打开 [SSR 页面](http://127.0.0.1:4174/ssr) 和 [CSR 页面](http://127.0.0.1:4174/csr)，按 Ctrl+C 停止。

无需 `npm install` 或 `npm run build`。端口被占用时可用 `PORT=4175 node server/index.js`。

## 目录与执行位置

```text
simple-ssr/
├── package.json
├── README.md
├── server/                         # 在 Node 中执行
│   ├── index.js                    # HTTP 入口、路由、公共文件白名单
│   ├── services/
│   │   └── product-service.js      # 读取并校验商品数据
│   └── views/
│       └── page.js                 # 生成完整 HTML 文档
├── public/                         # 通过 HTTP 交给浏览器
│   ├── js/
│   │   └── main.js                 # 浏览器取数、填充商品、绑定事件
│   └── css/
│       └── style.css               # 浏览器使用的样式
├── shared/
│   └── render-product.js           # Node 与浏览器共用的纯模板、文字转义
├── data/
│   └── product.json                # 服务端读取的数据文件
└── captures/                       # 已保存的页面截图与原始响应
    ├── ssr-page.jpg
    ├── csr-page.jpg
    ├── ssr-response.html.txt
    └── csr-response.html.txt
```

浏览器请求 `/js/main.js`、`/css/style.css` 时，服务端分别读取 `public/` 中对应的文件；`/shared/render-product.js` 单独加入公共文件白名单，供浏览器导入。

`server/` 中的代码只在 Node 执行；`data/product.json` 由服务端读取。浏览器通过 `/api/product` 获取商品 JSON，不能直接通过文件路径访问服务端源码或数据文件。

## 按这个顺序看源码

1. **`server/index.js`**：先找到 `/ssr` 与 `/csr`。SSR 取到商品后生成完整页面；CSR 返回空的 `#product`。再看 `/api/product` 与公共文件路由。
2. **`server/services/product-service.js` → `data/product.json`**：确认两种方式使用同一个取数函数、同一份商品数据。
3. **`server/views/page.js` → `shared/render-product.js`**：前者拼完整文档，后者只生成商品正文。SSR 在 Node 中将两者组合后返回。
4. **`public/js/main.js`**：只有 CSR 先请求 `/api/product`，再用共享模板填充 `#product`；SSR 已有正文，直接使用。随后两页都给计数按钮绑定事件。
5. **`public/css/style.css`**：两页共用样式，不参与商品数据获取。

服务端返回的是生成后的 HTML；浏览器收到文档后解析它，再加载公共脚本和样式。本例的事件绑定使用原生 `addEventListener`，不涉及 React 水合。

## 一组对照怎么观察

两页最终的商品和交互相同。分别打开 DevTools → Network，刷新页面：

| 观察位置 | SSR | CSR |
| --- | --- | --- |
| 页面 document 的 Response | `#product` 中已有商品名称、价格和按钮 HTML | `#product` 为空，响应中没有商品名称 |
| `/api/product` 请求 | 没有；Node 直接取数 | 有一次；浏览器请求商品数据 |
| 计数按钮 | 脚本就绪后解除禁用，点击后累加 | 商品生成后解除禁用，点击后累加 |

在 Response 中搜索商品名，就能看到服务器实际返回的正文。Elements 展示的是脚本执行后的 DOM，不能代替原始响应。`captures/` 中也保留了两页的响应副本，当前响应以刷新后的 Network 记录为准。

在 DevTools 命令菜单选择 Disable JavaScript 后，**重新刷新**：SSR 仍显示商品，CSR 商品区域为空；两页的计数交互都需要 JavaScript。观察后用 Enable JavaScript 恢复并刷新。

编辑 `data/product.json` 中的商品名后刷新，两页都会读取新数据，无需重启或构建。修改服务端代码或服务端导入的共享模板后需重启 Node；修改浏览器脚本、样式后刷新即可。共享模板同时供两端使用，修改后应重启并刷新。

## 性能边界

这组对照说明正文在哪里生成，以及正文出现是否依赖客户端 JavaScript。没有人为延迟，也不预设 SSR 更快。

若观察 Performance，应固定缓存、网络、CPU 与视口。共同的页面标题也会参与 FCP，商品出现时间不一定等于 FCP；SSR 等待数据可能增加 TTFB，LCP 仍取决于候选内容和实际链路。本地轻量页面的差异可能很小。

两页使用相同脚本，不能据此声称 SSR 减少 JavaScript 体积、改善 INP 或 CLS。正文可见也不等于按钮已可交互；本地记录不能代表线上用户的第 75 百分位。
