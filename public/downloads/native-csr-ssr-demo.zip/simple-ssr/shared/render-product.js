// 服务端与浏览器共用的纯模板：只接受数据并返回 HTML，不访问 Node API 或 DOM。
export function escapeHtml(value) {
  const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(value).replace(/[&<>"']/g, (character) => entities[character]);
}

export function renderProduct(product) {
  return `<article class="product">
    <div class="product-art" aria-hidden="true"><div class="cup"></div></div>
    <div class="product-info">
      <p class="eyebrow">日常好物 / DEMO PRODUCT</p>
      <h2>${escapeHtml(product.name)}</h2>
      <p class="description">${escapeHtml(product.description)}</p>
      <dl class="details">
        <div><dt>材质</dt><dd>${escapeHtml(product.material)}</dd></div>
        <div><dt>容量</dt><dd>${escapeHtml(product.capacity)}</dd></div>
      </dl>
      <p class="price"><span>¥</span> ${escapeHtml(product.price)}</p>
      <button id="counter" type="button" disabled>点击次数：<span id="count" aria-live="polite">0</span></button>
      <p class="caption">商品信息为虚构；按钮用于观察 JavaScript 交互。</p>
    </div>
  </article>`;
}
