import { readFile } from 'node:fs/promises';

export async function loadProduct() {
  // 每次请求重新读取，而非启动时导入；修改数据后刷新即可看到变化。
  const file = new URL('../../data/product.json', import.meta.url);
  const product = JSON.parse(await readFile(file, 'utf8'));
  const fields = ['name', 'description', 'price', 'material', 'capacity'];
  if (!product || fields.some((field) => typeof product[field] !== 'string')) {
    throw new Error('Invalid demo product');
  }
  return product;
}
