import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { loadProduct } from './services/product-service.js';
import { renderPage } from './views/page.js';

const host = '127.0.0.1';
const port = Number(process.env.PORT ?? 4174);
const publicDirectory = new URL('../public/', import.meta.url);
const assets = new Map([
  ['/js/main.js', [new URL('js/main.js', publicDirectory), 'text/javascript; charset=utf-8']],
  ['/css/style.css', [new URL('css/style.css', publicDirectory), 'text/css; charset=utf-8']],
  ['/shared/render-product.js', [new URL('../shared/render-product.js', import.meta.url), 'text/javascript; charset=utf-8']],
]);

function send(req, res, status, contentType, body) {
  res.writeHead(status, {
    'Content-Type': contentType,
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(req.method === 'HEAD' ? undefined : body);
}

const server = createServer(async (req, res) => {
  try {
    const { pathname } = new URL(req.url, `http://${host}:${port}`);
    console.log(`${req.method} ${pathname}`);

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.setHeader('Allow', 'GET, HEAD');
      return send(req, res, 405, 'text/plain; charset=utf-8', 'Method Not Allowed');
    }

    if (pathname === '/') {
      res.writeHead(302, { Location: '/ssr', 'Cache-Control': 'no-store' });
      return res.end();
    }

    // SSR：在 Node 中取数，并把已生成的正文放入 HTML 响应。
    if (pathname === '/ssr') {
      const product = await loadProduct();
      return send(req, res, 200, 'text/html; charset=utf-8', renderPage('ssr', product));
    }

    // CSR：响应里只有空的商品容器，正文由 public/js/main.js 生成。
    if (pathname === '/csr') {
      return send(req, res, 200, 'text/html; charset=utf-8', renderPage('csr'));
    }

    // CSR 的数据接口与 SSR 调用同一个数据加载函数。
    if (pathname === '/api/product') {
      return send(req, res, 200, 'application/json; charset=utf-8', JSON.stringify(await loadProduct()));
    }

    // 只提供明确列出的公共文件，不把整个项目目录暴露给浏览器。
    if (assets.has(pathname)) {
      const [file, contentType] = assets.get(pathname);
      return send(req, res, 200, contentType, await readFile(file));
    }

    return send(req, res, 404, 'text/plain; charset=utf-8', 'Not Found');
  } catch {
    return send(req, res, 500, 'text/plain; charset=utf-8', '演示数据或页面加载失败，请检查本地文件。');
  }
});

server.listen(port, host, () => {
  console.log(`SSR: http://${host}:${port}/ssr`);
  console.log(`CSR: http://${host}:${port}/csr`);
  console.log('直接编辑文件并刷新；服务端逻辑修改后需重启。Ctrl+C 停止。');
});
