import { renderProduct } from '../../shared/render-product.js';

// 完整页面只在服务端生成；商品正文是否填入，由 SSR / CSR 模式决定。
export function renderPage(mode, product) {
  const isSSR = mode === 'ssr';
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${isSSR ? 'SSR' : 'CSR'} · 原生 JavaScript 实验</title>
  <link rel="icon" href="data:,">
  <link rel="stylesheet" href="/css/style.css">
  <script type="module" src="/js/main.js"></script>
</head>
<body data-mode="${isSSR ? 'ssr' : 'csr'}">
  <main>
    <header class="page-header">
      <a class="brand" href="/ssr">原生 JS <span>/ 渲染实验</span></a>
      <nav aria-label="渲染方式">
        <a href="/csr"${!isSSR ? ' aria-current="page"' : ''}>CSR</a>
        <a href="/ssr"${isSSR ? ' aria-current="page"' : ''}>SSR</a>
      </nav>
    </header>
    <section class="intro">
      <p class="eyebrow">ONE PAGE, TWO WAYS TO RENDER</p>
      <h1>同一张卡片，两种显示方式。</h1>
      <p>${isSSR ? 'SSR：服务器读取数据，将商品 HTML 放入页面响应。' : 'CSR：浏览器加载 JavaScript、请求数据，再生成商品 HTML。'}</p>
    </section>
    <section id="product" aria-label="商品信息">${isSSR ? renderProduct(product) : ''}</section>
    <noscript><p class="notice">JavaScript 已禁用：SSR 仍显示商品，CSR 商品区域为空。计数按钮需要 JavaScript。</p></noscript>
    <aside class="guide">
      <span class="guide-number">01</span>
      <div><h2>看服务器返回了什么</h2><p>打开 DevTools → Network → 刷新 → 选择页面 document → Response。搜索商品名，对比两页的原始 HTML。</p></div>
    </aside>
    <footer>Node.js + HTML + CSS + JavaScript <span>零依赖 · 无构建 · 本地虚构数据</span></footer>
  </main>
</body>
</html>`;
}
