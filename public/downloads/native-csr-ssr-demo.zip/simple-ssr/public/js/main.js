import { renderProduct } from '/shared/render-product.js';

const container = document.querySelector('#product');

async function start() {
  // SSR 已经有商品 DOM；只有 CSR 需要在浏览器取数、生成正文。
  if (document.body.dataset.mode === 'csr') {
    const response = await fetch('/api/product');
    if (!response.ok) throw new Error('商品加载失败，请刷新重试。');
    container.innerHTML = renderProduct(await response.json());
  }

  // 两页执行相同的事件绑定。这是原生事件绑定，不是 React 水合。
  const button = document.querySelector('#counter');
  const count = document.querySelector('#count');
  let clicks = 0;
  button.addEventListener('click', () => {
    count.textContent = String(++clicks);
  });
  button.disabled = false;
}

start().catch(() => {
  const message = document.createElement('p');
  message.className = 'notice';
  message.setAttribute('role', 'alert');
  message.textContent = '页面交互加载失败，请刷新重试。';
  container.append(message);
});
